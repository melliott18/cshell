import fcntl,json,os,pathlib,select,signal,subprocess,sys,termios,time
sys.path.insert(0,'/var/folders/1s/p32k5z617vqc6qxm89nx29dc0000gn/T/csh057-resume-4cfpijns/tests')
import pty_harness
out=pathlib.Path('/tmp/csh057-pty-master.906IJQ');records=[]
for mode in ['original','close-before-wait']:
 master,slave=pty_harness.open_terminal();ready,w=os.pipe()
 def setup():fcntl.ioctl(0,termios.TIOCSCTTY,0);os.tcsetpgrp(0,os.getpgrp())
 p=subprocess.Popen([str(out/'unread'),'7',str(w)],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,preexec_fn=setup,pass_fds=(w,))
 os.close(slave);os.close(w);row={'mode':mode,'pid':p.pid}
 try:
  assert select.select([ready],[],[],1)[0]
  assert os.read(ready,1)==b'r'
  old_wait=p.wait
  if mode=='close-before-wait':
   def wait(timeout=None):
    null=os.open('/dev/null',os.O_RDWR);os.dup2(null,master);os.close(null)
    return old_wait(timeout=timeout)
   p.wait=wait
  started=time.monotonic();row['failures']=pty_harness.cleanup_session(p,master)
  row['elapsed']=time.monotonic()-started;row['status_before_final_close']=p.returncode
  p.wait=old_wait
 finally:os.close(ready);os.close(master)
 started=time.monotonic();row['status_after_final_close']=p.wait(timeout=1)
 row['wait_after_close_elapsed']=time.monotonic()-started
 records.append(row);print(json.dumps(row),flush=True)
(out/'cleanup-results.json').write_text(json.dumps(records,indent=2)+'\n')
