import inspect,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/var/folders/1s/p32k5z617vqc6qxm89nx29dc0000gn/T/csh057-resume-4cfpijns')
out=pathlib.Path('/tmp/csh057-pty-master.906IJQ')
sys.path.insert(0,str(root/'tests'))
import smoke,pty_harness
case=next(c for c in smoke.load_suite(root/'build/tests/jobs-pty.json')['cases'] if c['name']=='repeated background resumes preserve prompt and terminal')
original_cleanup=pty_harness.cleanup_session
for mode in ['baseline','drain','close']:
 record={'mode':mode}; owned=[]
 def cleanup(process,master,timeout=5.0):
  owned.append(process); old_wait=process.wait
  def wait(timeout=None):
   record['before_wait_poll']=process.poll()
   if mode=='drain':
    drained=bytearray();until=time.monotonic()+0.1
    while len(drained)<65536 and time.monotonic()<until:
     try:
      chunk=os.read(master,min(4096,65536-len(drained)))
      if not chunk:break
      drained.extend(chunk)
     except (BlockingIOError,OSError):break
    record['drained']=drained.decode(errors='replace')
   elif mode=='close':
    # Replace with an innocuous open descriptor so capture's finally closes
    # the replacement without ever closing an unrelated descriptor.
    null=os.open('/dev/null',os.O_RDWR)
    os.dup2(null,master);os.close(null)
   started=time.monotonic()
   try:
    status=old_wait(timeout=timeout);record['wait_status']=status;return status
   except subprocess.TimeoutExpired:
    record['wait_timeout']=True
    returncode=subprocess.run(['/bin/ps','-p',str(process.pid),'-o','pid=,ppid=,pgid=,stat=,wchan=,command='],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=.5)
    record['ps_after_wait']=returncode.stdout
    raise
   finally:record['wait_elapsed']=time.monotonic()-started
  process.wait=wait
  started=time.monotonic()
  try:return original_cleanup(process,master,timeout)
  finally:record['cleanup_elapsed']=time.monotonic()-started;process.wait=old_wait
 pty_harness.cleanup_session=cleanup
 started=time.monotonic();failures=smoke.run_case(root/'cshell',case,5,65536)
 record.update(elapsed=time.monotonic()-started,failures=failures,pid=owned[0].pid)
 started=time.monotonic()
 try:record['after_master_close_status']=owned[0].wait(timeout=1)
 except subprocess.TimeoutExpired:record['after_master_close_timeout']=True
 record['after_master_close_wait_elapsed']=time.monotonic()-started
 (out/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items() if k not in ['failures','ps_after_wait']}),flush=True)
