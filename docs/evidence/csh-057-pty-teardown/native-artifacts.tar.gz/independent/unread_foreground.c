#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char**argv)
{
    if(argc!=2)return 2;
    int ready=atoi(argv[1]);
    pid_t child=fork();
    if(child<0)return 3;
    if(child==0){for(;;)pause();}
    if(setpgid(child,child)<0||tcsetpgrp(0,child)<0)return 4;
    if(write(1,"queued\n",7)!=7)return 5;
    char message[64];int length=snprintf(message,sizeof(message),"%ld\n",(long)child);
    if(write(ready,message,(size_t)length)!=length)return 6;
    close(ready);for(;;)pause();
}
