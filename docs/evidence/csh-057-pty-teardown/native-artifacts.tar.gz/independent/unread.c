#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc,char**argv){char buffer[512];memset(buffer,'x',sizeof(buffer));if(argc!=3)return 2;int left=atoi(argv[1]),fd=atoi(argv[2]);while(left>0){ssize_t n=write(1,buffer,left>512?512:(size_t)left);if(n<0&&errno==EINTR)continue;if(n<=0)return 3;left-=(int)n;}if(write(fd,"r",1)!=1)return 4;close(fd);for(;;)pause();}
