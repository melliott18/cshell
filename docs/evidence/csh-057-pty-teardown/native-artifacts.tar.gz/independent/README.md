# CSH-057 independent PTY master dependency probes

These native Darwin probes were run independently of the main driver. No repository source was edited.

## Decisive bounded control

`held_slave_cleanup_probe.py` uses a C helper (`unread.c`, compiled as `unread`) which queues seven bytes then acknowledges completion over a separate pipe. The runner keeps one slave FD reference while cleanup executes. Its local `pty_harness.py` is the immutable version extracted with `git show 0f80030:tests/pty_harness.py`.

`held-slave-cleanup-results.json` shows the original cleanup reports its unchanged one-second exact-child reap failure. Closing the PTY master then makes that same owned child reap as SIGKILL in about 1.5 milliseconds. The comparison replaces the PTY master with `/dev/null` immediately before the same final wait; it preserves the original session group cleanup, observes status -9, and finishes in about 0.107 seconds with no cleanup failure. This descriptor replacement is an evidence-only adapter; the shipping fix consumes/closes the master before waiting.

Both children were reaped. Readiness is pipe synchronized, not an elapsed sleep assumption. The held slave FD controls terminal lifetime; it models another descriptor reference during leader exit. The simpler single-slave probes showed an approximately 0.6-second implicit drain timeout and could not deterministically exceed the harness's one-second reap deadline.

## Other retained outcomes

- `probe.py`, `baseline.json`, `drain.json`, and `close.json`: three runs of the full slowed helper case all preserved the original five-second case timeout but happened to clean up successfully. These are not a before/after proof.
- `unread_probe.py`: a minimal unread seven-byte output blocked SIGKILL reap for the initial 0.3-second wait; draining it released the exact child. Larger 4096/8192 writes did not reach the ready marker and are not equivalent readiness controls.
- `unread_long_probe.py` and `cleanup_probe.py`: without an extra slave reference, the kernel completed exit after approximately 0.6 seconds, so the old one-second cleanup could pass.
- `foreground_probe.py`: an exploratory separate foreground group also did not prevent that implicit timeout. The final run encountered EBADF because the imported mutable parent export had changed to consume the master. It is retained as a failed setup control, not a fixture defect. `foreground_old_probe.py` then used the immutable extracted harness and confirmed both variants could pass.

Scripts preserve their original absolute temporary paths. The compiled Mach-O helpers and their sources are retained. The manifest hashes every regular top-level file present before the manifest was written. These probes demonstrate the cleanup dependency; they do not establish a production runtime defect or uniquely establish the original hosted timeout's cause.
