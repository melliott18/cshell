import fcntl,json,os,pathlib,select,signal,subprocess,sys,termios,time
sys.path.insert(0,'/var/folders/1s/p32k5z617vqc6qxm89nx29dc0000gn/T/csh057-resume-4cfpijns/tests')
sys.path.insert(0,'/tmp/csh057-pty-master.906IJQ')
import pty_harness
out=pathlib.Path('/tmp/csh057-pty-master.906IJQ');records=[]
for mode in ['old-cleanup','close-cleanup']:
 master,slave=pty_harness.open_terminal();ready,w=os.pipe()
 def setup():fcntl.ioctl(0,termios.TIOCSCTTY,0);os.tcsetpgrp(0,os.getpgrp())
 p=subprocess.Popen([str(out/'unread_foreground'),str(w)],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,preexec_fn=setup,pass_fds=(w,))
 os.close(slave);os.close(w);row={'mode':mode,'pid':p.pid}
 try:
  assert select.select([ready],[],[],1)[0];data=os.read(ready,64);child=int(data);row['foreground_child']=child
  assert os.tcgetpgrp(master)==child
  if mode in ['drain','close']:
   os.killpg(child,signal.SIGKILL);os.killpg(p.pid,signal.SIGKILL);start=time.monotonic()
   try:row['before_status']=p.wait(timeout=1.3)
   except subprocess.TimeoutExpired:row['before_timeout']=True
   row['before_elapsed']=time.monotonic()-start
   if mode=='drain':
    try:row['drained']=os.read(master,4096).decode()
    except OSError as e:row['read_error']=repr(e)
   else:
    null=os.open('/dev/null',os.O_RDWR);os.dup2(null,master);os.close(null)
   start=time.monotonic()
   try:row['after_status']=p.wait(timeout=1)
   except subprocess.TimeoutExpired:row['after_timeout']=True
   row['after_elapsed']=time.monotonic()-start
  else:
   old_wait=p.wait
   if mode=='close-cleanup':
    def wait(timeout=None):
     null=os.open('/dev/null',os.O_RDWR);os.dup2(null,master);os.close(null);return old_wait(timeout=timeout)
    p.wait=wait
   start=time.monotonic();row['failures']=pty_harness.cleanup_session(p,master);row['elapsed']=time.monotonic()-start;row['status']=p.returncode;p.wait=old_wait
 finally:os.close(ready);os.close(master)
 start=time.monotonic();row['final_status']=p.wait(timeout=1);row['final_wait_elapsed']=time.monotonic()-start
 records.append(row);print(json.dumps(row),flush=True)
(out/'foreground-old-results.json').write_text(json.dumps(records,indent=2)+'\n')
