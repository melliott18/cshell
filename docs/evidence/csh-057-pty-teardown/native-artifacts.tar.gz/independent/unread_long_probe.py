import fcntl,json,os,pathlib,select,signal,subprocess,sys,termios,time
sys.path.insert(0,'/var/folders/1s/p32k5z617vqc6qxm89nx29dc0000gn/T/csh057-resume-4cfpijns/tests')
import pty_harness
out=pathlib.Path('/tmp/csh057-pty-master.906IJQ');records=[]
for amount in [7,7,7]:
 master,slave=pty_harness.open_terminal();ready,w=os.pipe()
 def setup():fcntl.ioctl(0,termios.TIOCSCTTY,0);os.tcsetpgrp(0,os.getpgrp())
 p=subprocess.Popen([str(out/'unread'),str(amount),str(w)],stdin=slave,stdout=slave,stderr=slave,start_new_session=True,preexec_fn=setup,pass_fds=(w,))
 os.close(slave);os.close(w)
 row={'amount':amount,'pid':p.pid}; available=select.select([ready],[],[],.5)[0];row['ready']=bool(available)
 if available:row['ready_byte']=os.read(ready,1).decode()
 os.close(ready);os.killpg(p.pid,signal.SIGKILL);start=time.monotonic()
 try:row['before_drain_status']=p.wait(timeout=1.3)
 except subprocess.TimeoutExpired:row['before_drain_timeout']=True
 row['before_drain_elapsed']=time.monotonic()-start
 data=bytearray()
 while len(data)<16384:
  try:
   b=os.read(master,4096)
   if not b:break
   data.extend(b)
  except OSError:break
 row['drained']=len(data);start=time.monotonic()
 try:row['after_drain_status']=p.wait(timeout=1.3)
 except subprocess.TimeoutExpired:row['after_drain_timeout']=True
 row['after_drain_elapsed']=time.monotonic()-start
 os.close(master);start=time.monotonic()
 try:row['after_close_status']=p.wait(timeout=1)
 except subprocess.TimeoutExpired:row['after_close_timeout']=True
 row['after_close_elapsed']=time.monotonic()-start
 records.append(row);print(json.dumps(row),flush=True)
(out/'unread-long-results.json').write_text(json.dumps(records,indent=2)+'\n')
