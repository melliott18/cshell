import argparse,inspect,json,time,sys,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--rounds',type=int,default=20);p.add_argument('--timeout',type=float,default=5);a=p.parse_args()
sys.path.insert(0,str(a.root/'tests'))
import smoke,pty_harness
trace={}
def mark(index,size):trace['steps'].append([round(time.monotonic()-trace['start'],6),index,size])
source=inspect.getsource(pty_harness._interact).replace('index += 1','index += 1; mark(index, len(output))')
namespace=dict(pty_harness.__dict__,mark=mark);exec(compile(source,'observed_interact','exec'),namespace)
def interact(process,master,steps,output,failures,deadline,timeout,output_limit):
 trace.update(pid=process.pid,start=deadline-timeout,steps=[])
 namespace['_interact'](process,master,steps,output,failures,deadline,timeout,output_limit)
 trace['interaction_seconds']=time.monotonic()-trace['start'];trace['interaction_failures']=list(failures);trace['output']=bytes(output).decode(errors='replace')
pty_harness._interact=interact
original_cleanup=pty_harness.cleanup_session
original_members=pty_harness.session_members
original_kill=pty_harness.kill_group
def members(session,deadline):
 start=time.monotonic()
 try:
  result=original_members(session,deadline);trace['cleanup_calls'].append({'operation':'snapshot','start':start-trace['start'],'seconds':time.monotonic()-start,'members':result});return result
 except Exception as e:
  trace['cleanup_calls'].append({'operation':'snapshot','start':start-trace['start'],'seconds':time.monotonic()-start,'error':repr(e)});raise
def kill(group,session,deadline):
 start=time.monotonic()
 try:
  result=original_kill(group,session,deadline);trace['cleanup_calls'].append({'operation':'kill_group','group':group,'start':start-trace['start'],'seconds':time.monotonic()-start});return result
 except Exception as e:
  trace['cleanup_calls'].append({'operation':'kill_group','group':group,'start':start-trace['start'],'seconds':time.monotonic()-start,'error':repr(e)});raise
def cleanup(process,master,timeout=5):
 trace['cleanup_calls']=[];start=time.monotonic();result=original_cleanup(process,master,timeout);trace['cleanup_seconds']=time.monotonic()-start;trace['cleanup_failures']=result;trace['returncode']=process.returncode
 if result:
  trace['post_failure_poll']=process.poll()
  for mode in ['held','closed']:
   if mode=='closed':
    null=os.open('/dev/null',os.O_RDWR);os.dup2(null,master);os.close(null)
   try:trace[mode+'_getsid']=os.getsid(process.pid)
   except OSError as e:trace[mode+'_getsid']=repr(e)
   observed=time.monotonic()
   try:
    status=process.wait(timeout=0.3);trace[mode+'_wait']={'status':status,'seconds':time.monotonic()-observed}
   except subprocess.TimeoutExpired:trace[mode+'_wait']={'status':None,'seconds':time.monotonic()-observed}
   trace[mode+'_ps']=subprocess.run(['/bin/ps','-p',str(process.pid),'-o','pid=,ppid=,pgid=,stat=,wchan=,command='],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=.5).stdout
 return result
pty_harness.cleanup_session=cleanup;pty_harness.session_members=members;pty_harness.kill_group=kill
case=next(c for c in smoke.load_suite(a.root/'build/tests/jobs-pty.json')['cases'] if c['name']=='repeated background resumes preserve prompt and terminal')
a.output.mkdir(parents=True,exist_ok=True)
(a.output/'case.json').write_text(json.dumps(case,indent=2)+'\n')
with (a.output/'rounds.jsonl').open('w') as log:
 for i in range(a.rounds):
  trace.clear();trace['round']=i+1
  failures=smoke.run_case(a.root/'cshell',case,a.timeout,65536);trace['failures']=failures
  log.write(json.dumps(trace)+'\n');log.flush()
  print(i+1,'FAIL' if failures else 'PASS',round(trace['interaction_seconds'],3),round(trace['cleanup_seconds'],3),flush=True)
  if trace.get('held_wait',{}).get('status',1) is None:break
