#define _DARWIN_C_SOURCE
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static double now(void) { struct timespec t; if(clock_gettime(CLOCK_MONOTONIC,&t)) abort(); return t.tv_sec+t.tv_nsec/1e9; }
int main(void) {
 struct sigaction action={0}; action.sa_handler=SIG_DFL; sigemptyset(&action.sa_mask); if(sigaction(SIGCHLD,&action,0)) return 2;
 unsigned gaps=0; double maximum=0;
 for(unsigned round=0;round<100;round++) {
  int ready[2],gate[2],status=0; if(pipe(ready)||pipe(gate)) return 2;
  pid_t p=fork(); if(p<0)return 2;
  if(!p){ close(ready[0]);close(gate[1]);if(setsid()<0)_exit(2);char *memory=malloc(64*1024*1024);if(!memory)_exit(2);for(size_t i=0;i<64*1024*1024;i+=4096)memory[i]=1;char b=1;if(write(ready[1],&b,1)!=1)_exit(2);if(read(gate[0],&b,1)<0)_exit(2);_exit(0); }
  close(ready[1]);close(gate[0]);char b;if(read(ready[0],&b,1)!=1)return 2;close(ready[0]);double start=now(),first=-1;close(gate[1]);
  for(;;){ errno=0;pid_t sid=getsid(p);int e=errno;pid_t waited=waitpid(p,&status,WNOHANG);double elapsed=now()-start;if(waited==p){if(first>=0){gaps++;if(elapsed-first>maximum)maximum=elapsed-first;printf("round=%u ESRCH-before-waitable=%.9f reap=%.9f gap=%.9f status=%d\n",round,first,elapsed,elapsed-first,status);}break;}if(waited<0)return 2;if(sid<0&&e==ESRCH&&first<0)first=elapsed;if(elapsed>2){kill(p,SIGKILL);double end=now()+1;while(now()<end){if(waitpid(p,&status,WNOHANG)==p)return 3;}return 4;}}
 }
 printf("rounds=100 gaps=%u max_observed_gap_seconds=%.9f\n",gaps,maximum);return 0;
}
