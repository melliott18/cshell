import sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path("tests").resolve()))
import pty_harness
old=pathlib.Path(sys.argv[1]).read_bytes()
exec(compile(old, sys.argv[1], "exec"), pty_harness.__dict__)
import test_pty_harness
suite=unittest.defaultTestLoader.loadTestsFromName("PtyHarnessTests.test_cleanup_reaps_a_killed_leader_with_unread_terminal_output", test_pty_harness)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
