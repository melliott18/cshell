#define CSH_TEST_PROVIDER "/bin/test"
