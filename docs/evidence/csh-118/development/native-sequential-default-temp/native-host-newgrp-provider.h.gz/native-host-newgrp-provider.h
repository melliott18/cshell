#define CSH_NEWGRP_PROVIDER "/usr/bin/newgrp"
