#define CSH_TEST_PROVIDER "/usr/local/bin/gtest"
