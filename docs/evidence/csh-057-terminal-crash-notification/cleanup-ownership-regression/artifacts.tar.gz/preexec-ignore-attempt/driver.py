import hashlib,json,os,pathlib,signal,subprocess,tempfile,time
root=pathlib.Path('/Users/mitchell/Projects/cshell')
out=root/'docs/evidence/csh-057-terminal-crash-notification/final-regression'
work=pathlib.Path(tempfile.mkdtemp(prefix='csh057-final-regression-'))
results=[]
flags=['-std=c99','-Wall','-Wextra','-Wpedantic','-Wshadow','-Werror','-g','-O1']
san=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def run(name,argv,expected=0,ignored=False,env=None):
 start=time.monotonic()
 result=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10,env=env,preexec_fn=(lambda:signal.signal(signal.SIGCHLD,signal.SIG_IGN)) if ignored else None)
 elapsed=time.monotonic()-start
 (out/(name+'.log')).write_bytes(result.stdout)
 row={'name':name,'command':argv,'returncode':result.returncode,'expected_returncode':expected,'elapsed_seconds':round(elapsed,6),'inherited_sigchld_ignored':ignored,'log':name+'.log'}
 results.append(row)
 assert result.returncode==expected,(name,result.returncode,result.stdout)
 assert b'unreaped crash notification child' not in result.stdout,(name,result.stdout)
 return result.stdout
source=root/'tests/crash_notification.c'
header=root/'tests/crash_notification.h'
wrapper=root/'docs/evidence/csh-057-terminal-crash-notification/reproduce_fixture.c'
normal=work/'crash_notification'
asan=work/'crash_notification_asan'
noop=work/'crash_notification_noop'
observed=work/'crash_notification_observed'
wrap=work/'reproduce_fixture'
run('build-normal',['cc','-Itests',*flags,str(source),'-o',str(normal)])
run('normal',[str(normal)])
run('build-sanitizer',['cc','-Itests',*flags,*san,str(source),'-o',str(asan)])
env=os.environ.copy();env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',MallocNanoZone='0')
run('sanitizer',[str(asan)],env=env)
needle='if (isolated && csh_test_clear_crash_notification() != 0) _exit(70);'
assert source.read_text().count(needle)==1
mutation=source.read_text().replace(needle,'if (isolated && 0) _exit(70); /* Deliberate helper no-op. */')
mutation_path=work/'crash_notification_noop.c';mutation_path.write_text(mutation)
run('build-helper-noop',['cc','-Itests',*flags,str(mutation_path),'-o',str(noop)])
run('helper-noop',[str(noop)],expected=1)
# Observe exact signals in the ignored-SIGCHLD control. The negative scenario
# legitimately sends one QUIT and one KILL; cleanup must add no further kill.
observer=work/'observe_kill.c'
observer.write_text('#include <signal.h>\n#include <stdio.h>\n#include <sys/types.h>\nint csh_regression_kill(pid_t child,int number){fprintf(stderr,"observed kill pid=%ld signal=%d\\n",(long)child,number);return kill(child,number);}\n')
obj=work/'crash_notification_observed.o'
run('build-observed-object',['cc','-Itests',*flags,'-Dkill=csh_regression_kill','-c',str(source),'-o',str(obj)])
run('build-observed',['cc',*flags,str(obj),str(observer),'-o',str(observed)])
ignored=run('ignored-sigchld',[str(observed)],expected=1,ignored=True)
import re
signals=[int(n) for n in re.findall(rb'observed kill pid=\d+ signal=(\d+)',ignored)]
assert signals==[signal.SIGQUIT,signal.SIGKILL],signals
results[-1]['observed_signals']=signals
results[-1]['cleanup_sent_no_additional_signal']=True
run('sanitizer-ignored-sigchld',[str(asan)],expected=1,ignored=True,env=env)
run('build-reproduction-wrapper',['cc',*flags,str(wrapper),'-o',str(wrap)])
run('reproduction-wrapper',[str(wrap),'0','/usr/bin/true'])
# Its ECHILD path must report failure without signaling an unowned launcher.
wrap_obj=work/'reproduce_fixture_observed.o'
wrap_observed=work/'reproduce_fixture_observed'
run('build-wrapper-observed-object',['cc',*flags,'-Dkill=csh_regression_kill','-c',str(wrapper),'-o',str(wrap_obj)])
run('build-wrapper-observed',['cc',*flags,str(wrap_obj),str(observer),'-o',str(wrap_observed)])
ignored=run('wrapper-ignored-sigchld',[str(wrap_observed),'0','/usr/bin/true'],expected=1,ignored=True)
assert b'observed kill' not in ignored
results[-1]['cleanup_sent_no_signal']=True
# Keep the diagnostic mutation, signal observer, and build/run driver available.
(out/'observe_kill.c').write_bytes(observer.read_bytes())
(out/'helper-noop.patch').write_text('Replace exactly in tests/crash_notification.c:\n'+needle+'\nwith:\nif (isolated && 0) _exit(70); /* Deliberate helper no-op. */\n')
manifest={'purpose':'Final cleanup ownership regression; earlier native/Linux archives are unchanged.','temporary_build_directory':str(work),'source_sha256':{str(p.relative_to(root)):digest(p) for p in [source,header,wrapper]},'binary_sha256':{p.name:digest(p) for p in [normal,asan,noop,observed,wrap,wrap_observed]},'results':results,'log_sha256':{p.name:digest(p) for p in sorted(out.glob('*.log'))}}
(out/'results.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'work':str(work),'results_directory':str(out),'checks':len(results),'outcome':'passed'},indent=2))
