#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
static void ignore_child(void) __attribute__((constructor));
static void ignore_child(void){struct sigaction a; if(signal(SIGCHLD,SIG_IGN)==SIG_ERR || sigaction(SIGCHLD,NULL,&a)<0 || a.sa_handler!=SIG_IGN)exit(90);fprintf(stderr,"SIGCHLD ignored before fixture fork\n");}
int csh_regression_kill(pid_t child,int number){fprintf(stderr,"observed kill pid=%ld signal=%d\n",(long)child,number);return kill(child,number);}
