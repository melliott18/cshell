#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
static void restored(void) {
    struct sigaction action;
    if (sigaction(SIGCHLD, NULL, &action) < 0 || action.sa_handler != SIG_IGN) _Exit(91);
    fprintf(stderr, "SIGCHLD ignore restored after fixture\n");
}
static void ignored(void) __attribute__((constructor));
static void ignored(void) {
    struct sigaction action;
    if (signal(SIGCHLD, SIG_IGN) == SIG_ERR || sigaction(SIGCHLD, NULL, &action) < 0 || action.sa_handler != SIG_IGN) _Exit(90);
    atexit(restored);
    fprintf(stderr, "SIGCHLD ignored before fixture fork\n");
}
int csh_regression_kill(pid_t child, int number) {
    fprintf(stderr, "observed kill pid=%ld signal=%d\n", (long)child, number);
    return kill(child, number);
}
