import json,pathlib,sys,time
sys.path.insert(0,"/Users/mitchell/Projects/cshell/tests")
import smoke
case=smoke.load_suite(pathlib.Path("/Users/mitchell/Projects/cshell/tests/fixtures/jobs-fault-pty.json"))["cases"][0]
start=time.monotonic()
failures=smoke.run_case(pathlib.Path(sys.argv[1]),case,5,65536)
result={"binary":sys.argv[1],"case":case,"seconds":time.monotonic()-start,"failures":failures}
pathlib.Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result),flush=True)
sys.exit(bool(failures))
