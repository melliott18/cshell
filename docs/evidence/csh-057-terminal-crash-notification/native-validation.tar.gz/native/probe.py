import json,pathlib,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).parent/'tests'))
import retention_diagnostics as d,smoke
root=pathlib.Path(__file__).parent
case=smoke.load_suite(root/'tests/fixtures/jobs-fault-pty.json')['cases'][0]
records=[]
for i in range(100):
 r=d.run_case(root/'build/tests/execute_faults',case,root/'probes',timeout=5,total_threshold=2,operation_threshold=2,sample_timeout=2.5)
 records.append(r)
 (root/'probe-results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(i,round(r['capture_duration_seconds'],3),r['failures'],flush=True)
 if r['failures']:break
