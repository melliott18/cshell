#define _DARWIN_C_SOURCE
#include <errno.h>
#include <mach/mach.h>
#include <mach/ndr.h>
#include <signal.h>
#include <spawn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
extern char **environ;
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec/1e9; }
static void delay(void) { struct timespec t = {0,10000000}; nanosleep(&t, NULL); }
static int reap(pid_t child, double seconds) { int status; pid_t got; double end = now()+seconds; do { got=waitpid(child,&status,WNOHANG); if(got==child){printf("reaped pid=%ld signal=%d exit=%d\n",(long)child,WIFSIGNALED(status)?WTERMSIG(status):0,WIFEXITED(status)?WEXITSTATUS(status):-1); return WIFSIGNALED(status)&&WTERMSIG(status)==SIGQUIT?0:1;} if(got<0){perror("waitpid");return 1;} delay(); }while(now()<end); fprintf(stderr,"reap timeout pid=%ld\n",(long)child);return 1; }
static void snapshot(pid_t child) { char pidtext[32]; pid_t ps; int status; snprintf(pidtext,sizeof(pidtext),"%ld",(long)child); char *a[]={"/bin/ps","-p",pidtext,"-o","pid,ppid,pgid,state,wchan,command",NULL}; if(posix_spawn(&ps,a[0],NULL,NULL,a,environ)==0){double end=now()+0.5;while(waitpid(ps,&status,WNOHANG)==0&&now()<end)delay();if(waitpid(ps,&status,WNOHANG)==0){kill(ps,SIGKILL); waitpid(ps,&status,0);}} }
int main(int argc,char**argv) {
    int clear=argc>1&&strcmp(argv[1],"clear")==0; int gate[2], status=0;
    struct rlimit lim={0,0}; if(setrlimit(RLIMIT_CORE,&lim)||pipe(gate))return 2;
    sigset_t blocked, prior; sigemptyset(&blocked);sigaddset(&blocked,SIGQUIT);if(sigprocmask(SIG_BLOCK,&blocked,&prior)||signal(SIGQUIT,SIG_DFL)==SIG_ERR)return 2;
    exception_mask_t masks[EXC_TYPES_COUNT]; mach_msg_type_number_t count=EXC_TYPES_COUNT;
    exception_handler_t ports[EXC_TYPES_COUNT]; exception_behavior_t behaviors[EXC_TYPES_COUNT];thread_state_flavor_t flavors[EXC_TYPES_COUNT];
    kern_return_t kr=task_get_exception_ports(mach_task_self(),EXC_MASK_CRASH,masks,&count,ports,behaviors,flavors);
    if(kr!=KERN_SUCCESS){fprintf(stderr,"getports=%d\n",kr);return 2;}
    mach_port_t server=MACH_PORT_NULL;
    kr=mach_port_allocate(mach_task_self(),MACH_PORT_RIGHT_RECEIVE,&server);
    if(kr!=KERN_SUCCESS)return 2;
    kr=mach_port_insert_right(mach_task_self(),server,server,MACH_MSG_TYPE_MAKE_SEND);if(kr!=KERN_SUCCESS)return 2;
    kr=task_set_exception_ports(mach_task_self(),EXC_MASK_CRASH,server,EXCEPTION_DEFAULT,THREAD_STATE_NONE);
    if(kr!=KERN_SUCCESS){fprintf(stderr,"setports=%d\n",kr);return 2;}
    pid_t child=fork();
    if(child!=0) {
        task_set_exception_ports(mach_task_self(),EXC_MASK_CRASH,MACH_PORT_NULL,EXCEPTION_DEFAULT,THREAD_STATE_NONE);
        for(mach_msg_type_number_t i=0;i<count;i++){task_set_exception_ports(mach_task_self(),masks[i],ports[i],behaviors[i],flavors[i]); if(ports[i]!=MACH_PORT_NULL)mach_port_deallocate(mach_task_self(),ports[i]);}
    }
    if(child<0){perror("fork");mach_port_mod_refs(mach_task_self(),server,MACH_PORT_RIGHT_RECEIVE,-1);return 2;}
    if(!child){ char c; close(gate[1]);
        if(clear){kern_return_t r=task_set_exception_ports(mach_task_self(),EXC_MASK_CRASH,MACH_PORT_NULL,EXCEPTION_DEFAULT,THREAD_STATE_NONE);if(r!=KERN_SUCCESS)_exit(70);}
        ssize_t n; do{n=read(gate[0],&c,1);}while(n<0&&errno==EINTR);if(n!=0)_exit(71);close(gate[0]);
        sigprocmask(SIG_SETMASK,&prior,NULL); _exit(72);
    }
    close(gate[0]);setpgid(child,child); kill(child,SIGQUIT);close(gate[1]);sigprocmask(SIG_SETMASK,&prior,NULL);
    union {mach_msg_header_t header; unsigned char buffer[4096];} message;
    kr=mach_msg(&message.header,MACH_RCV_MSG|MACH_RCV_TIMEOUT,0,sizeof(message),server,2000,MACH_PORT_NULL);
    printf("mode=%s child=%ld receive=%d id=%d bits=0x%x size=%u\n",clear?"clear":"hold",(long)child,kr,kr==KERN_SUCCESS?message.header.msgh_id:0,kr==KERN_SUCCESS?message.header.msgh_bits:0,kr==KERN_SUCCESS?message.header.msgh_size:0);fflush(stdout);
    if(kr==KERN_SUCCESS){
        pid_t got=waitpid(child,&status,WNOHANG);printf("before kill waitpid=%ld errno=%d\n",(long)got,errno);fflush(stdout);snapshot(child);
        errno=0;int k=kill(child,SIGKILL);printf("kill result=%d errno=%d\n",k,errno);fflush(stdout);
        double until=now()+0.3;while(now()<until)delay();got=waitpid(child,&status,WNOHANG);printf("after kill waitpid=%ld errno=%d\n",(long)got,errno);fflush(stdout);snapshot(child);
        struct {mach_msg_header_t header;NDR_record_t ndr;kern_return_t result;} reply;
        memset(&reply,0,sizeof(reply)); reply.header.msgh_bits=MACH_MSGH_BITS(MACH_MSG_TYPE_MOVE_SEND_ONCE,0);reply.header.msgh_size=sizeof(reply);reply.header.msgh_remote_port=message.header.msgh_remote_port;reply.header.msgh_id=message.header.msgh_id+100;reply.ndr=NDR_record;reply.result=KERN_SUCCESS;
        kr=mach_msg(&reply.header,MACH_SEND_MSG|MACH_SEND_TIMEOUT,sizeof(reply),0,MACH_PORT_NULL,500,MACH_PORT_NULL);printf("reply=%d\n",kr);fflush(stdout);
        message.header.msgh_remote_port=MACH_PORT_NULL;mach_msg_destroy(&message.header);
    }
    mach_port_mod_refs(mach_task_self(),server,MACH_PORT_RIGHT_RECEIVE,-1);
    int result=reap(child,2.0);
    if(result){kill(child,SIGKILL);return 1;}
    return clear?(kr==MACH_RCV_TIMED_OUT?0:1):(kr==KERN_SUCCESS?0:1);
}
