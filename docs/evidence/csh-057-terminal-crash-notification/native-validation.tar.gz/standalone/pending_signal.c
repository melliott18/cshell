#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
static double now(void) { struct timespec t; assert(clock_gettime(CLOCK_MONOTONIC, &t) == 0); return t.tv_sec + t.tv_nsec/1e9; }
int main(int argc, char **argv) {
    int number = argc > 1 ? atoi(argv[1]) : SIGQUIT;
    struct rlimit lim = {0, 0};
    assert(setrlimit(RLIMIT_CORE, &lim) == 0);
    for (int i = 0; i < 50; ++i) {
        sigset_t blocked, previous; int gate[2], status = 0;
        sigemptyset(&blocked); sigaddset(&blocked, number);
        assert(sigprocmask(SIG_BLOCK, &blocked, &previous) == 0);
        assert(signal(number, SIG_DFL) != SIG_ERR);
        assert(pipe(gate) == 0);
        double start = now(); pid_t child = fork(); assert(child >= 0);
        if (!child) {
            char c; ssize_t n; close(gate[1]);
            do { n = read(gate[0], &c, 1); } while (n < 0 && errno == EINTR);
            assert(n == 0); close(gate[0]);
            assert(sigprocmask(SIG_SETMASK, &previous, NULL) == 0);
            _exit(99);
        }
        close(gate[0]); assert(setpgid(child, child) == 0);
        assert(kill(child, number) == 0); close(gate[1]);
        assert(sigprocmask(SIG_SETMASK, &previous, NULL) == 0);
        pid_t observed; double bound = start + 3.0;
        while ((observed = waitpid(child, &status, WNOHANG)) == 0 && now() < bound) {
            struct timespec delay = {0, 1000000}; nanosleep(&delay, NULL);
        }
        if (!observed) { fprintf(stderr, "timeout i=%d signal=%d child=%ld elapsed=%.6f\n", i, number, (long)child, now()-start); kill(child, SIGKILL); return 1; }
        assert(observed == child && WIFSIGNALED(status) && WTERMSIG(status) == number);
        printf("signal=%d iteration=%d elapsed=%.6f\n", number, i, now()-start); fflush(stdout);
    }
    return 0;
}
