#define CSH_NEWGRP_PROVIDER "/bin/newgrp"
