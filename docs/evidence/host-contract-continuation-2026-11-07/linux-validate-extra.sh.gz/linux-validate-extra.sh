#!/bin/sh
set -eu
mkdir -p build/completion/sanitizer-bin
cp -a build/host-patch-source/patch-2.8 build/completion/patch-sanitizer-source
make -C build/completion/patch-sanitizer-source/lib clean > build/completion/patch-sanitizer-build.log 2>&1
make -C build/completion/patch-sanitizer-source/src clean >> build/completion/patch-sanitizer-build.log 2>&1
make -C build/completion/patch-sanitizer-source/lib -j2 CFLAGS='-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer' >> build/completion/patch-sanitizer-build.log 2>&1
make -C build/completion/patch-sanitizer-source/src -j2 CFLAGS='-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer' LDFLAGS='-fsanitize=address,undefined' >> build/completion/patch-sanitizer-build.log 2>&1
ln -s /work/build/completion/patch-sanitizer-source/src/patch build/completion/sanitizer-bin/patch
python3 tests/host_languages.py ./cshell --path /work/build/completion/sanitizer-bin:/work/build/host-profile/bin:/usr/bin:/bin --case 'patch/*' --sanitizer --record build/completion/patch-sanitizer.json > build/completion/patch-sanitizer.log 2>&1
cc -std=c99 -Wall -Wextra -Wpedantic -Wshadow -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer tests/host_formatted_interrupt.c -o build/completion/sanitizer-bin/printf-interrupt
cc -std=c99 -Wall -Wextra -Wpedantic -Wshadow -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -DHOST_FORMATTED_ECHO tests/host_formatted_interrupt.c -o build/completion/sanitizer-bin/echo-interrupt
PYTHONPATH=tests python3 - <<'PY'
from pathlib import Path
from host_formatted_environments import interrupt_cases
import json
rows=list(interrupt_cases(Path('cshell').resolve(),Path('build/host-profile/bin').resolve(),{u:Path('build/completion/sanitizer-bin/'+u+'-interrupt').resolve() for u in ('printf','echo')}))
Path('build/completion/interrupt-sanitizer.json').write_text(json.dumps(rows,indent=2)+'\n')
print({s:sum(r['verdict']==s for r in rows) for s in ('PASS','FAIL')})
raise SystemExit(any(r['verdict']=='FAIL' for r in rows))
PY
PATH=/work/build/host-profile/bin:/usr/bin:/bin make test-runtime test-pty > build/completion/runtime.log 2>&1
make test-host-text-faults > build/completion/text-faults.log 2>&1
