import json,os,sys,tempfile
from pathlib import Path
from collections import Counter
sys.path.insert(0,'tests')
from host_utilities import inventory, source_identity
from host_text_streams import run_cases
from host_formatted_environments import interrupt_cases
root=Path.cwd(); path=str(root/'build/host-profile/bin')+os.pathsep+os.defpath
records={}
records['streams']=run_cases(root/'cshell',path,inventory(path,('cat','tee','tail')),None)
with tempfile.TemporaryDirectory() as work:
 records['interrupt']=list(interrupt_cases(root/'cshell',Path(work)/'bin',{u:root/('build/tests/host_'+u+'_interrupt') for u in ('printf','echo')}))
records['source']=source_identity()
records['providers']=inventory(path,('cat','tee','tail'))
Path(sys.argv[1]).write_text(json.dumps(records,indent=2)+'\n')
for name in ('streams','interrupt'):
 print(name,Counter(r['verdict'] for r in records[name]))
 for r in records[name]:
  if r['verdict']!='PASS':print(r)
raise SystemExit(any(r['verdict']!='PASS' for name in ('streams','interrupt') for r in records[name]))
