set -e
csh_awk_root=$1
csh_results=$2
mkdir -p build/third-sanitizer-bin "$csh_results"
csh_gnulib_dir=build/host-format-sanitizer/build/host-m4-source/m4-1.4.20/lib
cc -std=c99 -O1 -g -Wall -Wextra -Wpedantic -Wshadow -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -I"$csh_gnulib_dir" -include "$csh_gnulib_dir/config.h" -DPROGVERSION='"1.22.6-cshell.2-asan"' tools/host-profile/vendor/ed/*.c "$csh_gnulib_dir/libm4.a" -o build/third-sanitizer-bin/ed
cc -std=c99 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I"$csh_gnulib_dir" -include "$csh_gnulib_dir/config.h" -include tests/host_ed_faults.h -DPROGVERSION='"1.22.6-cshell.2-asan-faults"' tools/host-profile/vendor/ed/*.c tests/host_ed_faults.c "$csh_gnulib_dir/libm4.a" -o build/third-ed-faults-asan
ln -sf "$PWD/$csh_awk_root/build/host-awk" build/third-sanitizer-bin/awk
ln -sf "$PWD/build/host-format-sanitizer/build/host-m4" build/third-sanitizer-bin/m4
python3 tests/host_languages.py ./cshell --path "$PWD/build/third-sanitizer-bin:$PWD/build/host-profile/bin:/bin:/usr/bin" --case 'awk/*' --case 'ed/*' --case 'm4/*' --ed-faults build/third-ed-faults-asan --sanitizer --record "$csh_results/languages.json" > "$csh_results/languages.log" 2>&1
python3 tests/host_formatted.py --sanitizer --record "$csh_results/formatted.json" > "$csh_results/formatted.log" 2>&1
