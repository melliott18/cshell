import json,sys,tempfile,platform
from pathlib import Path
sys.path.insert(0,'tests')
from host_formatted import capture
from host_utilities import serial,source_identity,sha
rows=[]; helper=Path('build/tests/host_printf_resources').resolve()
for kind in (('stack','memory') if platform.system()=='Linux' else ('stack',)):
 with tempfile.TemporaryDirectory() as root:
  status,out,errors,measured=capture(helper,dict(args=[kind],stdin='',env={'LC_ALL':'C'}),Path(root),400000)
  ok=not errors and measured and measured['soft']==(65536 if kind=='stack' else 16777216)
  ok=ok and (status==0 and out['stdout']==b'x'*262145 and not out['stderr'] if kind=='stack' else status==1 and not out['stdout'] and out['stderr']==b'host_printf_resources: write or formatting error: Cannot allocate memory\n')
  rows.append(dict(kind=kind,verdict='PASS' if ok else 'FAIL',status=status,output=serial(out),errors=errors,measured=measured))
Path(sys.argv[1]).write_text(json.dumps(dict(platform=platform.platform(),source=source_identity(),helper_sha256=sha(helper),cases=rows),indent=2)+'\n')
print([(r['kind'],r['verdict']) for r in rows]);raise SystemExit(any(r['verdict']!='PASS' for r in rows))
