FROM cshell-services:csh-078-qualified
RUN make -B build/host-uudecode CFLAGS="-std=c99 -Wall -Wextra -Wpedantic -Wshadow -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer" LDFLAGS="-fsanitize=address,undefined"
ENV ASAN_OPTIONS=halt_on_error=1:detect_leaks=0:abort_on_error=0
ENV UBSAN_OPTIONS=halt_on_error=1:abort_on_error=0
