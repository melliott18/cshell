import os,sys,unittest
from pathlib import Path
sys.path.insert(0,'tests')
import test_host_filesystem as test
original = os.kill
observed = []
def kill(pid, signum):
    result=original(pid,signum)
    if signum == 0:
        try:
            value=Path('/proc/'+str(pid)+'/stat').read_text()
            observed.append(value)
            print('VISIBLE_PID', value, flush=True)
        except FileNotFoundError:
            print('REAPED_BETWEEN_PROBES',pid,flush=True)
    return result
os.kill=kill
suite=unittest.TestSuite(test.FilesystemHarnessTests('test_metadata_timeout_cleans_process_and_fixture_in_every_mode') for _ in range(12))
result=unittest.TextTestRunner(verbosity=2).run(suite)
print('VISIBLE_OBSERVATIONS',len(observed),flush=True)
